package com.rpkeyboard.data

import android.content.Context
import org.json.JSONObject

val PRESET_MODES = listOf("event", "action", "try", "chat")

fun modeLabel(m: String): String = when (m) {
    "event" -> "Событие"
    "action" -> "Действие"
    "try" -> "Попытка"
    "chat" -> "Обычный чат"
    else -> m
}

val PALETTE_NAMES = listOf("Ночь", "Графит", "Океан", "Лес", "Закат", "Сирень")

data class KbSettings(
    val themeMode: Int = 1, // 0 светлая, 1 тёмная, 2 системная
    val palette: Int = 0,
    val heightDp: Int = 300,
    val heightLandDp: Int = 180,
    val btnDp: Int = 48,
    val textSp: Int = 14,
    val columns: Int = 2,
    val previewLines: Int = 2,
    val hintMode: Boolean = true,
    val showRecents: Boolean = true,
    val showFavorites: Boolean = true,
    val chatLimit: Int = 0,
    val suggest: Boolean = true,
    val nextWord: Boolean = true,
    val emojiSuggest: Boolean = true,
    val autoCaps: Boolean = false,
    val learn: Boolean = true,
    val clipboard: Boolean = true,
    val incognito: Boolean = false,
    val bgAlpha: Int = 100,
    val keyAlpha: Int = 100,
    val animations: Boolean = true,
    val sound: Boolean = false,
    val vibration: Boolean = true,
    val numberRow: Boolean = false,
    val cursorKeys: Boolean = true,
    val panelVisible: Boolean = true,
    val langs: String = "ru,en",
    val curLang: String = "ru"
)

fun KbSettings.toJson(): JSONObject = JSONObject()
    .put("themeMode", themeMode).put("palette", palette).put("heightDp", heightDp)
    .put("heightLandDp", heightLandDp).put("btnDp", btnDp).put("textSp", textSp)
    .put("columns", columns).put("previewLines", previewLines).put("hintMode", hintMode)
    .put("showRecents", showRecents).put("showFavorites", showFavorites).put("chatLimit", chatLimit)
    .put("suggest", suggest).put("nextWord", nextWord).put("emojiSuggest", emojiSuggest)
    .put("autoCaps", autoCaps).put("learn", learn).put("clipboard", clipboard)
    .put("incognito", incognito).put("bgAlpha", bgAlpha).put("keyAlpha", keyAlpha)
    .put("animations", animations).put("sound", sound).put("vibration", vibration)
    .put("numberRow", numberRow).put("cursorKeys", cursorKeys).put("panelVisible", panelVisible)
    .put("langs", langs).put("curLang", curLang)

fun settingsFromJson(o: JSONObject, d: KbSettings = KbSettings()) = KbSettings(
    themeMode = o.optInt("themeMode", d.themeMode),
    palette = o.optInt("palette", d.palette),
    heightDp = o.optInt("heightDp", d.heightDp),
    heightLandDp = o.optInt("heightLandDp", d.heightLandDp),
    btnDp = o.optInt("btnDp", d.btnDp),
    textSp = o.optInt("textSp", d.textSp),
    columns = o.optInt("columns", d.columns),
    previewLines = o.optInt("previewLines", d.previewLines),
    hintMode = o.optBoolean("hintMode", d.hintMode),
    showRecents = o.optBoolean("showRecents", d.showRecents),
    showFavorites = o.optBoolean("showFavorites", d.showFavorites),
    chatLimit = o.optInt("chatLimit", d.chatLimit),
    suggest = o.optBoolean("suggest", d.suggest),
    nextWord = o.optBoolean("nextWord", d.nextWord),
    emojiSuggest = o.optBoolean("emojiSuggest", d.emojiSuggest),
    autoCaps = o.optBoolean("autoCaps", d.autoCaps),
    learn = o.optBoolean("learn", d.learn),
    clipboard = o.optBoolean("clipboard", d.clipboard),
    incognito = o.optBoolean("incognito", d.incognito),
    bgAlpha = o.optInt("bgAlpha", d.bgAlpha),
    keyAlpha = o.optInt("keyAlpha", d.keyAlpha),
    animations = o.optBoolean("animations", d.animations),
    sound = o.optBoolean("sound", d.sound),
    vibration = o.optBoolean("vibration", d.vibration),
    numberRow = o.optBoolean("numberRow", d.numberRow),
    cursorKeys = o.optBoolean("cursorKeys", d.cursorKeys),
    panelVisible = o.optBoolean("panelVisible", d.panelVisible),
    langs = o.optString("langs", d.langs),
    curLang = o.optString("curLang", d.curLang)
)

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("rp_settings", Context.MODE_PRIVATE)

    fun load(): KbSettings {
        val j = p.getString("json", null)
        if (j != null) {
            try {
                return settingsFromJson(JSONObject(j))
            } catch (_: Exception) {
            }
        }
        // перенос настроек из старых версий
        val d = KbSettings()
        return d.copy(
            themeMode = if (p.getBoolean("dark", true)) 1 else 0,
            heightDp = p.getInt("height", d.heightDp),
            heightLandDp = p.getInt("height_land", d.heightLandDp),
            btnDp = p.getInt("btn", d.btnDp),
            textSp = p.getInt("text", d.textSp),
            columns = p.getInt("cols", d.columns),
            previewLines = p.getInt("preview", d.previewLines),
            hintMode = p.getBoolean("hint", true),
            showRecents = p.getBoolean("recents", true),
            showFavorites = p.getBoolean("favs", true),
            chatLimit = p.getInt("chat_limit", 0),
            suggest = p.getBoolean("suggest", true),
            learn = p.getBoolean("learn", true),
            clipboard = p.getBoolean("clipboard", true)
        )
    }

    fun save(s: KbSettings) {
        p.edit().putString("json", s.toJson().toString()).apply()
    }

    fun resetSettings() {
        p.edit().remove("json").apply()
        save(KbSettings())
    }

    var lastFolder: Long?
        get() = p.getLong("lastFolder", -1L).takeIf { it >= 0 }
        set(v) { p.edit().putLong("lastFolder", v ?: -1L).apply() }

    var emojiRecent: String
        get() = p.getString("emoji_recent", "") ?: ""
        set(v) { p.edit().putString("emoji_recent", v).apply() }

    var seeded: Boolean
        get() = p.getBoolean("seeded", false)
        set(v) { p.edit().putBoolean("seeded", v).apply() }
}
