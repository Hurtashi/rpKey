package com.rpkeyboard.data

/** Раскладка языка. extra — дополнительные символы по долгому нажатию, h3 — значки третьего ряда. */
data class Lang(
    val code: String,
    val name: String,
    val rows: List<String>,
    val extra: Map<String, List<String>>,
    val h3: List<String>,
    val cyr: Boolean
)

private val H3_LAT = listOf("*", "\"", "'", ":", ";", "!", "?", "_", "-")

val LANGS: List<Lang> = listOf(
    Lang(
        "ru", "Русский", listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю"),
        mapOf("е" to listOf("ё")),
        listOf("*", "\"", "'", ":", ";", "!", "ъ", "?", "_"), true
    ),
    Lang("en", "English", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), emptyMap(), H3_LAT, false),
    Lang(
        "uk", "Українська", listOf("йцукенгшщзхї", "фівапролджє", "ячсмитьбю"),
        mapOf("г" to listOf("ґ")), H3_LAT, true
    ),
    Lang(
        "de", "Deutsch", listOf("qwertzuiopü", "asdfghjklöä", "yxcvbnm"),
        mapOf("s" to listOf("ß")), H3_LAT, false
    ),
    Lang(
        "es", "Español", listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm"),
        mapOf("a" to listOf("á"), "e" to listOf("é"), "i" to listOf("í"), "o" to listOf("ó"), "u" to listOf("ú", "ü")),
        H3_LAT, false
    ),
    Lang(
        "fr", "Français", listOf("azertyuiop", "qsdfghjklm", "wxcvbn"),
        mapOf(
            "e" to listOf("é", "è", "ê", "ë"), "a" to listOf("à", "â"), "u" to listOf("ù", "û"),
            "i" to listOf("î", "ï"), "o" to listOf("ô"), "c" to listOf("ç")
        ),
        H3_LAT, false
    )
)

fun langByCode(code: String): Lang = LANGS.firstOrNull { it.code == code } ?: LANGS[0]

fun enabledLangs(csv: String): List<String> =
    csv.split(",").map { it.trim() }.filter { c -> LANGS.any { it.code == c } }.distinct().ifEmpty { listOf("ru") }
