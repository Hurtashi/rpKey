package com.rpkeyboard.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.rpkeyboard.data.KbSettings

private class Pal(
    val bg: Long, val key: Long, val special: Long,
    val accent: Long, val onAccent: Long, val text: Long, val sub: Long
)

private val DARK = listOf(
    Pal(0xFF181A28, 0xFF2A2D3F, 0xFF373B54, 0xFFDDE3FF, 0xFF1A1C2B, 0xFFEDEDF2, 0xFF9EA2B8), // Ночь
    Pal(0xFF17181A, 0xFF2E3033, 0xFF3F4146, 0xFFCFE3FF, 0xFF14181F, 0xFFEDEDED, 0xFF9A9DA3), // Графит
    Pal(0xFF0E1F24, 0xFF1B3A42, 0xFF245058, 0xFF8FE9DD, 0xFF06201E, 0xFFE6F4F4, 0xFF8FB3B8), // Океан
    Pal(0xFF14201A, 0xFF22372B, 0xFF2D4A39, 0xFFB5EDAE, 0xFF0F2410, 0xFFE8F2EA, 0xFF93B39C), // Лес
    Pal(0xFF25161A, 0xFF40262C, 0xFF553239, 0xFFFFC2A0, 0xFF2D140A, 0xFFF6E9EA, 0xFFC09AA0), // Закат
    Pal(0xFF1E1829, 0xFF342A46, 0xFF45385C, 0xFFE6D2FF, 0xFF24143A, 0xFFF0EAF7, 0xFFAB9EC4)  // Сирень
)

private val LIGHT = listOf(
    Pal(0xFFD7DBE3, 0xFFFFFFFF, 0xFFB9C0D0, 0xFF3B5BDB, 0xFFFFFFFF, 0xFF1B1B1F, 0xFF5A5D68),
    Pal(0xFFD9DADC, 0xFFFFFFFF, 0xFFBEC0C4, 0xFF3A3F47, 0xFFFFFFFF, 0xFF1B1B1F, 0xFF5E6066),
    Pal(0xFFD3E6E8, 0xFFFFFFFF, 0xFFA9CED2, 0xFF0F7C86, 0xFFFFFFFF, 0xFF102022, 0xFF4F6B6E),
    Pal(0xFFD8E6D9, 0xFFFFFFFF, 0xFFB0CFB4, 0xFF2F7D3A, 0xFFFFFFFF, 0xFF11200F, 0xFF536B57),
    Pal(0xFFEBDCD6, 0xFFFFFFFF, 0xFFDFBFB5, 0xFFC2562B, 0xFFFFFFFF, 0xFF2A1510, 0xFF77584E),
    Pal(0xFFE2DCEB, 0xFFFFFFFF, 0xFFC8BBDB, 0xFF7A3FC2, 0xFFFFFFFF, 0xFF1F1330, 0xFF6A5A82)
)

@Composable
fun RpTheme(s: KbSettings, content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val dark = when (s.themeMode) {
        0 -> false
        1 -> true
        else -> sys
    }
    val p = (if (dark) DARK else LIGHT)[s.palette.coerceIn(0, DARK.lastIndex)]
    val cs = if (dark) {
        darkColorScheme(
            primary = Color(p.accent), onPrimary = Color(p.onAccent),
            background = Color(p.bg), onBackground = Color(p.text),
            surface = Color(p.bg), onSurface = Color(p.text),
            surfaceVariant = Color(p.key), onSurfaceVariant = Color(p.sub),
            secondaryContainer = Color(p.special), onSecondaryContainer = Color(p.text)
        )
    } else {
        lightColorScheme(
            primary = Color(p.accent), onPrimary = Color(p.onAccent),
            background = Color(p.bg), onBackground = Color(p.text),
            surface = Color(p.bg), onSurface = Color(p.text),
            surfaceVariant = Color(p.key), onSurfaceVariant = Color(p.sub),
            secondaryContainer = Color(p.special), onSecondaryContainer = Color(p.text)
        )
    }
    MaterialTheme(colorScheme = cs, content = content)
}
