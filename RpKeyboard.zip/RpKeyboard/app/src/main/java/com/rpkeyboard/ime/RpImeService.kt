package com.rpkeyboard.ime

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.rpkeyboard.RpApp
import com.rpkeyboard.data.KbSettings
import com.rpkeyboard.data.Prefs
import com.rpkeyboard.data.SuggItem
import com.rpkeyboard.data.TemplateEntity
import com.rpkeyboard.data.enabledLangs
import com.rpkeyboard.data.modeLabel
import com.rpkeyboard.ui.MainActivity
import com.rpkeyboard.ui.RpTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class RpImeService : InputMethodService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private val ks = KbState()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val repo by lazy { (application as RpApp).repo }
    private val suggester by lazy { (application as RpApp).suggester }
    private val clips by lazy { (application as RpApp).clips }
    private lateinit var prefs: Prefs
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private var smart = true
    private var imeLearnOk = true

    override fun onCreate() {
        super.onCreate()
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        prefs = (application as RpApp).prefs
        ks.settings = prefs.load()
        syncLang()
        ks.folderId = prefs.lastFolder
        ks.clips = clips.list()
        ks.emojiRecent = prefs.emojiRecent.split(" ").filter { it.isNotEmpty() }
        scope.launch {
            repo.templates.collect { list -> suggester.setLibrary(list.map { it.name + " " + it.text }) }
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val listener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged(cm) }
        clipListener = listener
        cm.addPrimaryClipChangedListener(listener)
    }

    override fun onCreateInputView(): View {
        window.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }
        val actions = KeyActions(
            type = { s -> typeText(s) },
            backspace = { doBackspace() },
            enter = { doEnter() },
            cursor = { d -> moveCursor(d) },
            nextLang = { nextLang() },
            insert = { t -> insertTemplate(t) },
            toggleFav = { t -> scope.launch { repo.toggleFav(t) } },
            openSettings = {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            pick = { item -> pick(item) },
            paste = { t -> pasteText(t) },
            clipPin = { c ->
                clips.togglePin(c.text)
                ks.clips = clips.list()
            },
            clipDelete = { c ->
                clips.remove(c.text)
                ks.clips = clips.list()
            },
            clipClear = {
                clips.clearAll()
                ks.clips = clips.list()
            },
            update = { f -> update(f) }
        )
        val view = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent { RpTheme(ks.settings) { KeyboardRoot(ks, repo, actions) } }
        }
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        return view
    }

    /** Не уходить в полноэкранный режим в ландшафте: важно для игр. */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        ks.settings = prefs.load()
        syncLang()
        ks.password = isPassword(info)
        if (ks.password) ks.panel = Panel.NONE
        smart = isSmartField(info)
        imeLearnOk = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) == 0
        ks.clips = clips.list()
        refresh()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        prefs.lastFolder = ks.folderId
        suggester.save()
        prefs.emojiRecent = ks.emojiRecent.joinToString(" ")
    }

    override fun onDestroy() {
        clipListener?.let {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(it)
        }
        prefs.emojiRecent = ks.emojiRecent.joinToString(" ")
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        store.clear()
        suggester.save()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ настройки и языки

    private fun syncLang() {
        val l = enabledLangs(ks.settings.langs)
        ks.lang = if (ks.settings.curLang in l) ks.settings.curLang else l.first()
    }

    private fun update(f: (KbSettings) -> KbSettings) {
        val n = f(ks.settings)
        ks.settings = n
        prefs.save(n)
        syncLang()
        refresh()
    }

    private fun nextLang() {
        val l = enabledLangs(ks.settings.langs)
        val i = l.indexOf(ks.lang)
        val next = l[(i + 1) % l.size]
        update { it.copy(curLang = next) }
    }

    /** Новые слова запоминаются, только если обучение включено и режим инкогнито выключен. */
    private fun canLearn(): Boolean =
        ks.settings.learn && !ks.settings.incognito && !ks.password && imeLearnOk

    // ------------------------------------------------------------ ввод текста

    private fun textBefore(n: Int): String = currentInputConnection?.getTextBeforeCursor(n, 0)?.toString() ?: ""

    private fun trailingWord(t: String): String {
        var i = t.length
        while (i > 0 && t[i - 1].isLetter()) i--
        return t.substring(i)
    }

    private fun updateCaps() {
        val ic = currentInputConnection
        val info = currentInputEditorInfo
        ks.autoShift = ks.settings.autoCaps && ic != null && info != null && info.inputType != 0 &&
            ic.getCursorCapsMode(info.inputType) != 0
    }

    private fun refresh() {
        updateCaps()
        val s = ks.settings
        if (!s.suggest || !smart || ks.password || ks.panel != Panel.NONE) {
            ks.suggestions = emptyList()
            return
        }
        val t = textBefore(60)
        val cur = trailingWord(t)
        var list: List<SuggItem>
        var emoji: String? = null
        if (cur.isNotEmpty()) {
            list = suggester.suggest(ks.lang, cur)
        } else {
            val prev = Regex("(\\p{L}+)\\s$").find(t)?.groupValues?.get(1) ?: ""
            list = if (prev.isNotEmpty() && s.nextWord) suggester.nextWords(ks.lang, prev) else emptyList()
            if (s.emojiSuggest && prev.isNotEmpty()) emoji = suggester.emojiFor(prev)
        }
        if (emoji != null) list = list.take(2) + SuggItem(emoji, 1)
        ks.suggestions = list.take(3)
    }

    /** Текст вставляется как есть: ни заглавных, ни пробелов после знаков препинания не добавляется. */
    private fun typeText(s: String) {
        val ic = currentInputConnection ?: return
        val boundary = s.length == 1 && !s[0].isLetterOrDigit()
        if (boundary && smart && canLearn()) learnCurrentWord()
        ic.commitText(s, 1)
        refresh()
    }

    private fun learnCurrentWord() {
        val t = textBefore(80)
        val cur = trailingWord(t)
        if (cur.length < 2) return
        val before = t.dropLast(cur.length)
        val sentenceStart = before.trimEnd().let { it.isEmpty() || it.last() in ".!?\n" }
        val capName = cur[0].isUpperCase() && cur.drop(1).all { it.isLowerCase() } && !sentenceStart
        suggester.learn(ks.lang, cur, capName)
        Regex("(\\p{L}+) $").find(before)?.let { suggester.learnPair(ks.lang, it.groupValues[1], cur) }
    }

    private fun pick(item: SuggItem) {
        val ic = currentInputConnection ?: return
        when (item.kind) {
            0 -> {
                val t = textBefore(80)
                val cur = trailingWord(t)
                if (cur.isNotEmpty()) ic.deleteSurroundingText(cur.length, 0)
                ic.commitText(item.text + " ", 1)
                if (canLearn() && smart) {
                    suggester.learn(ks.lang, item.text)
                    val before = t.dropLast(cur.length)
                    Regex("(\\p{L}+) $").find(before)?.let { suggester.learnPair(ks.lang, it.groupValues[1], item.text) }
                }
            }
            1 -> ic.commitText(item.text, 1)
            else -> if (canLearn()) suggester.learn(ks.lang, item.text) else suggester.ignore(ks.lang, item.text)
        }
        refresh()
    }

    private fun doBackspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        refresh()
    }

    private fun moveCursor(d: Int) {
        sendDownUpKeyEvents(if (d < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
        refresh()
    }

    private fun pasteText(t: String) {
        currentInputConnection?.commitText(t, 1)
        refresh()
    }

    /** Вставляет только текст шаблона. Ничего не отправляет. */
    private fun insertTemplate(t: TemplateEntity) {
        currentInputConnection?.commitText(t.text, 1)
        val limit = ks.settings.chatLimit
        val over = limit > 0 && t.text.length > limit
        val parts = mutableListOf<String>()
        if (ks.settings.hintMode) parts.add("Режим чата: ${modeLabel(t.mode)}")
        if (over) parts.add("⚠ ${t.text.length} из $limit символов")
        ks.hintWarn = over
        ks.hint = parts.joinToString(" · ").ifEmpty { null }
        scope.launch { repo.touch(t.id) }
    }

    /** Enter нажимает сам пользователь; приложение само ничего не отправляет. */
    private fun doEnter() {
        val ic = currentInputConnection ?: return
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        ks.suggestions = emptyList()
    }

    private fun onClipChanged(cm: ClipboardManager) {
        val s = ks.settings
        if (!s.clipboard || s.incognito || ks.password) return
        try {
            val clip = cm.primaryClip ?: return
            val sensitive = Build.VERSION.SDK_INT >= 28 &&
                clip.description.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true
            if (sensitive) return
            val text = clip.getItemAt(0)?.coerceToText(this)?.toString() ?: return
            clips.add(text)
            ks.clips = clips.list()
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ тип поля

    private fun isSmartField(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return true
        if (t == 0) return true
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        return v == InputType.TYPE_TEXT_VARIATION_NORMAL ||
            v == InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE ||
            v == InputType.TYPE_TEXT_VARIATION_LONG_MESSAGE
    }

    private fun isPassword(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (
            v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }
}
