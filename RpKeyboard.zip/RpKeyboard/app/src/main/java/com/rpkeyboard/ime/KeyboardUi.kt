package com.rpkeyboard.ime

import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import android.view.View
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items as listItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import com.rpkeyboard.data.ClipItem
import com.rpkeyboard.data.EMOJI_CATS
import com.rpkeyboard.data.FolderEntity
import com.rpkeyboard.data.FolderInfo
import com.rpkeyboard.data.KbSettings
import com.rpkeyboard.data.Lang
import com.rpkeyboard.data.Repo
import com.rpkeyboard.data.SuggItem
import com.rpkeyboard.data.TemplateEntity
import com.rpkeyboard.data.buildInfo
import com.rpkeyboard.data.langByCode
import com.rpkeyboard.data.modeLabel
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val LocalKb = compositionLocalOf { KbSettings() }

enum class Screen { FOLDER, FAVORITES, RECENTS, SEARCH }
enum class Panel { NONE, RP, CLIP, EMOJI }

class KbState {
    var settings by mutableStateOf(KbSettings())
    var panel by mutableStateOf(Panel.NONE)
    var password by mutableStateOf(false)
    var screen by mutableStateOf(Screen.FOLDER)
    var folderId by mutableStateOf<Long?>(null)
    var query by mutableStateOf("")
    var hint by mutableStateOf<String?>(null)
    var hintWarn by mutableStateOf(false)
    var lang by mutableStateOf("ru")
    var suggestions by mutableStateOf<List<SuggItem>>(emptyList())
    var autoShift by mutableStateOf(false)
    var clips by mutableStateOf<List<ClipItem>>(emptyList())
    var emojiRecent by mutableStateOf<List<String>>(emptyList())
    var emojiSearch by mutableStateOf(false)

    fun pushEmoji(e: String) {
        emojiRecent = (listOf(e) + emojiRecent.filter { it != e }).take(24)
    }

    /** Возвращает true, если удалось вернуться на шаг назад внутри библиотеки. */
    fun back(folders: List<FolderEntity>): Boolean {
        if (screen != Screen.FOLDER) {
            screen = Screen.FOLDER
            query = ""
            return true
        }
        val id = folderId ?: return false
        folderId = folders.firstOrNull { it.id == id }?.parentId
        return true
    }

    fun title(folders: List<FolderEntity>): String = when (screen) {
        Screen.FAVORITES -> "★ Избранное"
        Screen.RECENTS -> "🕘 Недавние"
        Screen.SEARCH -> "Поиск"
        Screen.FOLDER -> folderId?.let { id -> folders.firstOrNull { it.id == id }?.name } ?: "RP-библиотека"
    }
}

class KeyActions(
    val type: (String) -> Unit,
    val backspace: () -> Unit,
    val enter: () -> Unit,
    val cursor: (Int) -> Unit,
    val nextLang: () -> Unit,
    val insert: (TemplateEntity) -> Unit,
    val toggleFav: (TemplateEntity) -> Unit,
    val openSettings: () -> Unit,
    val pick: (SuggItem) -> Unit,
    val paste: (String) -> Unit,
    val clipPin: (ClipItem) -> Unit,
    val clipDelete: (ClipItem) -> Unit,
    val clipClear: () -> Unit,
    val update: ((KbSettings) -> KbSettings) -> Unit
)

sealed class GridItem(val key: String) {
    class F(val f: FolderEntity) : GridItem("f${f.id}")
    class V(val screen: Screen, val label: String) : GridItem("v${screen.name}")
    class T(val t: TemplateEntity) : GridItem("t${t.id}")
}

// ====================================================================== корень

@Composable
fun KeyboardRoot(ks: KbState, repo: Repo, act: KeyActions) {
    val s = ks.settings
    val cs = MaterialTheme.colorScheme
    val folders by repo.folders.collectAsState(initial = emptyList())
    val templates by repo.templates.collectAsState(initial = emptyList())
    val recents by repo.recents.collectAsState(initial = emptyList())
    val cfg = LocalConfiguration.current
    val land = cfg.screenHeightDp < cfg.screenWidthDp

    val typing = ks.panel == Panel.NONE || ks.password
    val searching = !ks.password && ((ks.panel == Panel.RP && ks.screen == Screen.SEARCH) || ks.emojiSearch)
    val base = if (land) (if (searching) 250 else s.heightLandDp) else s.heightDp
    val heightDp = base.coerceAtMost((cfg.screenHeightDp * 0.75f).toInt())
    val showSugg = typing && !ks.password && s.suggest && ks.suggestions.isNotEmpty()
    val showStrip = !ks.password && (s.panelVisible || showSugg)

    CompositionLocalProvider(LocalKb provides s) {
        Column(
            Modifier
                .fillMaxWidth()
                .height(heightDp.dp)
                .background(cs.background.copy(alpha = s.bgAlpha / 100f))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            if (!ks.password) ArrowRow(ks, act)
            if (showStrip) {
                Box(Modifier.fillMaxWidth().height(38.dp)) {
                    if (showSugg) SuggestionStrip(ks, act) else ToolRow(ks, act)
                }
                Spacer(Modifier.height(2.dp))
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    typing -> TypingKeyboard(
                        Modifier.fillMaxSize(), langByCode(ks.lang), act.type, act.backspace, act.enter,
                        act.nextLang, ks.autoShift, s.numberRow, s.cursorKeys, act.cursor
                    )
                    ks.panel == Panel.RP -> RpPanel(ks, folders, templates, recents, act)
                    ks.panel == Panel.CLIP -> ClipPanel(Modifier.fillMaxSize(), ks, act) { ks.panel = Panel.NONE }
                    else -> EmojiPanel(
                        Modifier.fillMaxSize(), ks,
                        { e ->
                            act.type(e)
                            ks.pushEmoji(e)
                        },
                        act
                    ) { ks.panel = Panel.NONE }
                }
            }
        }
    }
}

@Composable
private fun ArrowRow(ks: KbState, act: KeyActions) {
    val s = ks.settings
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth().height(20.dp)) {
        Box(
            Modifier
                .align(Alignment.Center)
                .width(80.dp)
                .fillMaxHeight()
                .tap {
                    if (s.panelVisible) ks.panel = Panel.NONE
                    act.update { it.copy(panelVisible = !it.panelVisible) }
                },
            contentAlignment = Alignment.Center
        ) {
            Text(if (s.panelVisible) "▲" else "▼", fontSize = 11.sp, color = cs.onSurfaceVariant)
        }
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .clip(RoundedCornerShape(6.dp))
                .background(if (s.incognito) cs.primary.copy(alpha = 0.35f) else Color.Transparent)
                .tap { act.update { it.copy(incognito = !it.incognito) } }
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(if (s.incognito) "🕶\uFE0F Инкогнито" else "🕶\uFE0F", fontSize = 11.sp, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun ToolRow(ks: KbState, act: KeyActions) {
    val cs = MaterialTheme.colorScheme
    val kb = LocalKb.current
    val items: List<Pair<String, Panel?>> = listOf("📚" to Panel.RP, "📋" to Panel.CLIP, "⚙" to null, "😊" to Panel.EMOJI)
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        items.forEach { (icon, p) ->
            val active = p != null && ks.panel == p
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (active) cs.primary else cs.surfaceVariant.copy(alpha = cs.surfaceVariant.alpha * kb.keyAlpha / 100f)
                    )
                    .tap {
                        if (p == null) act.openSettings()
                        else ks.panel = if (ks.panel == p) Panel.NONE else p
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(icon, fontSize = 20.sp)
            }
        }
    }
}

@Composable
private fun SuggestionStrip(ks: KbState, act: KeyActions) {
    val cs = MaterialTheme.colorScheme
    val kb = LocalKb.current
    val list = ks.suggestions.take(3)
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        list.forEach { it ->
            val warn = it.kind == 2
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .background(cs.secondaryContainer.copy(alpha = kb.keyAlpha / 100f))
                    .tap { act.pick(it) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (warn) "“${it.text}”" else it.text,
                    fontSize = if (it.kind == 1) 22.sp else 15.sp,
                    color = if (warn) cs.error else cs.onSecondaryContainer,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        repeat(3 - list.size) { Spacer(Modifier.weight(1f)) }
    }
}

@Composable
private fun SmallBtn(label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .width(40.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(cs.surfaceVariant)
            .tap { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
    }
}

// ====================================================================== RP-библиотека

@Composable
private fun RpPanel(
    ks: KbState,
    folders: List<FolderEntity>,
    templates: List<TemplateEntity>,
    recents: List<TemplateEntity>,
    act: KeyActions
) {
    val s = ks.settings
    val cs = MaterialTheme.colorScheme
    val cfg = LocalConfiguration.current
    val land = cfg.screenHeightDp < cfg.screenWidthDp
    val info = remember(folders, templates) { buildInfo(folders, templates) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().height(34.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SmallBtn("←") { if (!ks.back(folders)) ks.panel = Panel.NONE }
            SmallBtn("🔍") {
                ks.screen = if (ks.screen == Screen.SEARCH) Screen.FOLDER else Screen.SEARCH
                ks.query = ""
            }
            SmallBtn("★") { ks.screen = Screen.FAVORITES }
            Text(
                ks.title(folders), Modifier.weight(1f).padding(horizontal = 6.dp),
                fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(2.dp))
        val h = ks.hint
        if (h != null && (s.hintMode || ks.hintWarn)) {
            Text(
                h, Modifier.fillMaxWidth().padding(bottom = 2.dp, start = 4.dp),
                fontSize = 12.sp, color = if (ks.hintWarn) cs.error else cs.primary, maxLines = 1
            )
        }
        if (ks.screen == Screen.SEARCH) {
            Box(
                Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(8.dp))
                    .background(cs.surfaceVariant).padding(horizontal = 10.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    if (ks.query.isEmpty()) "Поиск по шаблонам и папкам…" else ks.query,
                    fontSize = 14.sp,
                    color = if (ks.query.isEmpty()) cs.onSurfaceVariant else cs.onSurface,
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(3.dp))
            val results = remember(ks.query, templates, folders) { search(ks.query, templates, folders) }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                CardGrid(results.map { GridItem.T(it) }, ks, act, info)
            }
            Spacer(Modifier.height(3.dp))
            TypingKeyboard(
                Modifier.fillMaxWidth().height(if (land) 110.dp else 172.dp),
                langByCode(ks.lang),
                { ks.query += it },
                { ks.query = ks.query.dropLast(1) },
                null,
                act.nextLang
            )
        } else {
            val items = remember(ks.screen, ks.folderId, folders, templates, recents, s.showFavorites, s.showRecents) {
                when (ks.screen) {
                    Screen.FAVORITES -> templates.filter { it.favorite }.map { GridItem.T(it) }
                    Screen.RECENTS -> recents.map { GridItem.T(it) }
                    else -> buildList<GridItem> {
                        if (ks.folderId == null) {
                            if (s.showFavorites) add(GridItem.V(Screen.FAVORITES, "★ Избранное"))
                            if (s.showRecents) add(GridItem.V(Screen.RECENTS, "🕘 Недавние"))
                        }
                        folders.filter { it.parentId == ks.folderId }.forEach { add(GridItem.F(it)) }
                        templates.filter { it.folderId == ks.folderId }.forEach { add(GridItem.T(it)) }
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) { CardGrid(items, ks, act, info) }
        }
    }
}

private fun search(q: String, templates: List<TemplateEntity>, folders: List<FolderEntity>): List<TemplateEntity> {
    val query = q.trim().lowercase()
    if (query.isEmpty()) return emptyList()
    val names = folders.associate { it.id to it.name.lowercase() }
    return templates.filter {
        it.name.lowercase().contains(query) ||
            it.text.lowercase().contains(query) ||
            (it.folderId?.let { id -> names[id] }?.contains(query) == true)
    }
}

@Composable
private fun CardGrid(list: List<GridItem>, ks: KbState, act: KeyActions, info: Map<Long, FolderInfo>) {
    val s = ks.settings
    val cfg = LocalConfiguration.current
    val land = cfg.screenHeightDp < cfg.screenWidthDp
    val cols = if (land) (s.columns + 2).coerceAtMost(6) else s.columns
    LazyVerticalGrid(
        columns = GridCells.Fixed(cols),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(list, key = { it.key }) { item ->
            when (item) {
                is GridItem.F -> {
                    val fi = info[item.f.id]
                    Card(
                        "📁 ${item.f.name}",
                        fi?.preview()?.ifEmpty { null },
                        fi?.let { "папок: ${it.subs} · шаблонов: ${it.templates}" },
                        true, s,
                        {
                            ks.folderId = item.f.id
                            ks.screen = Screen.FOLDER
                        },
                        null
                    )
                }
                is GridItem.V -> Card(item.label, null, null, true, s, { ks.screen = item.screen }, null)
                is GridItem.T -> {
                    val len = item.t.text.length
                    val over = s.chatLimit > 0 && len > s.chatLimit
                    val sub = listOfNotNull(
                        if (s.hintMode) modeLabel(item.t.mode) else null,
                        if (over) "⚠ $len/${s.chatLimit}" else null
                    ).joinToString(" · ").ifEmpty { null }
                    Card(
                        (if (item.t.favorite) "★ " else "") + item.t.name,
                        item.t.text, sub, false, s,
                        { act.insert(item.t) },
                        { act.toggleFav(item.t) }
                    )
                }
            }
        }
    }
}

@Composable
private fun Card(
    text: String, body: String?, sub: String?, accent: Boolean, s: KbSettings,
    onTap: () -> Unit, onLong: (() -> Unit)?
) {
    val cs = MaterialTheme.colorScheme
    val showBody = body != null && s.previewLines > 0
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = s.btnDp.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (accent) cs.secondaryContainer else cs.surfaceVariant)
            .tap(onLong, onTap)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text, fontSize = s.textSp.sp,
            fontWeight = if (showBody) FontWeight.Medium else FontWeight.Normal,
            color = if (accent) cs.onSecondaryContainer else cs.onSurface,
            maxLines = if (showBody) 2 else 3, overflow = TextOverflow.Ellipsis
        )
        if (showBody) {
            Text(
                body!!, fontSize = (s.textSp - 2).coerceAtLeast(9).sp,
                color = cs.onSurfaceVariant, maxLines = s.previewLines, overflow = TextOverflow.Ellipsis
            )
        }
        if (sub != null) Text(sub, fontSize = (s.textSp - 4).coerceAtLeast(9).sp, color = cs.primary)
    }
}

// ====================================================================== буфер обмена

@Composable
private fun ClipPanel(modifier: Modifier, ks: KbState, act: KeyActions, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var preview by remember { mutableStateOf<ClipItem?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val list = remember(ks.clips) { ks.clips.sortedByDescending { it.pinned } }
    Box(modifier) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (!ks.settings.clipboard) {
                    Text(
                        "История буфера выключена в настройках приложения.",
                        Modifier.align(Alignment.Center).padding(16.dp), color = cs.onSurfaceVariant, fontSize = 14.sp
                    )
                } else if (list.isEmpty()) {
                    Text(
                        "Буфер пуст. Скопируйте текст, и он появится здесь.",
                        Modifier.align(Alignment.Center).padding(16.dp), color = cs.onSurfaceVariant, fontSize = 14.sp
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listItems(list, key = { it.text }) { c ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    c.text,
                                    Modifier.weight(1f).tap(onLong = { preview = c }) { act.paste(c.text) }.padding(10.dp),
                                    fontSize = ks.settings.textSp.sp, maxLines = 3,
                                    overflow = TextOverflow.Ellipsis, color = cs.onSurface
                                )
                                Text(if (c.pinned) "📌" else "📍", Modifier.tap { act.clipPin(c) }.padding(10.dp), fontSize = 16.sp)
                                Text("✕", Modifier.tap { act.clipDelete(c) }.padding(10.dp), fontSize = 16.sp, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Key("ABC", 1.5f, true) { onClose() }
                Key("Очистить всё", 2.5f) { if (list.isNotEmpty()) confirm = true }
                Spacer(Modifier.weight(2f))
                RepeatKey("⌫", 1.5f, true, act.backspace)
            }
        }
        val pv = preview
        if (pv != null) {
            Column(
                Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)).background(cs.background).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    pv.text,
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                    fontSize = 14.sp, color = cs.onSurface
                )
                Row(Modifier.fillMaxWidth().height(42.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Key("Вставить", 1.4f, false, active = true) {
                        act.paste(pv.text)
                        preview = null
                    }
                    Key(if (pv.pinned) "Открепить" else "Закрепить", 1.4f, true) {
                        act.clipPin(pv)
                        preview = null
                    }
                    Key("Удалить", 1.2f, true) {
                        act.clipDelete(pv)
                        preview = null
                    }
                    Key("✕", 0.8f, true) { preview = null }
                }
            }
        }
        if (confirm) {
            Column(
                Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)).background(cs.background).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Очистить весь буфер обмена?", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
                Text("Будут удалены все записи, в том числе закреплённые.", fontSize = 13.sp, color = cs.onSurfaceVariant)
                Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Key("Очистить", 1f, false, active = true) {
                        act.clipClear()
                        confirm = false
                    }
                    Key("Отмена", 1f, true) { confirm = false }
                }
            }
        }
    }
}

// ====================================================================== эмодзи

@Composable
private fun EmojiPanel(modifier: Modifier, ks: KbState, onPick: (String) -> Unit, act: KeyActions, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val cfg = LocalConfiguration.current
    val land = cfg.screenHeightDp < cfg.screenWidthDp
    val recent = ks.emojiRecent
    var cat by remember { mutableIntStateOf(if (recent.isNotEmpty()) 0 else 1) }
    var search by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    DisposableEffect(search) {
        ks.emojiSearch = search
        onDispose { ks.emojiSearch = false }
    }
    val list: List<String> = when {
        search -> {
            val t = q.trim().lowercase()
            if (t.isEmpty()) emptyList()
            else EMOJI_CATS.flatMap { it.items }.filter { it.kw.contains(t) }.map { it.e }.distinct()
        }
        cat == 0 -> recent
        else -> EMOJI_CATS[cat - 1].items.map { it.e }
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (search) {
            Row(
                Modifier.fillMaxWidth().height(34.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(8.dp))
                        .background(cs.surfaceVariant).padding(horizontal = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        if (q.isEmpty()) "Поиск эмодзи (например: сердце, машина, love)…" else q,
                        fontSize = 14.sp, maxLines = 1,
                        color = if (q.isEmpty()) cs.onSurfaceVariant else cs.onSurface
                    )
                }
                SmallBtn("✕") {
                    search = false
                    q = ""
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                (listOf("🕘") + EMOJI_CATS.map { it.icon }).forEachIndexed { i, icon ->
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (i == cat) cs.secondaryContainer else Color.Transparent)
                            .tap { cat = i },
                        contentAlignment = Alignment.Center
                    ) { Text(icon, fontSize = 18.sp) }
                }
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    if (search) "Ничего не найдено" else "Пока пусто",
                    color = cs.onSurfaceVariant, fontSize = 14.sp
                )
            }
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(8), modifier = Modifier.weight(1f).fillMaxWidth()) {
                items(list) { e ->
                    Box(Modifier.height(44.dp).tap { onPick(e) }, contentAlignment = Alignment.Center) {
                        Text(e, fontSize = 24.sp)
                    }
                }
            }
        }
        if (search) {
            TypingKeyboard(
                Modifier.fillMaxWidth().height(if (land) 110.dp else 172.dp),
                langByCode(ks.lang),
                { q += it },
                { q = q.dropLast(1) },
                null,
                act.nextLang
            )
        } else {
            Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Key("ABC", 1.5f, true) { onClose() }
                Key("🔍", 1.5f, true) { search = true }
                Spacer(Modifier.weight(4f))
                RepeatKey("⌫", 1.5f, true, act.backspace)
            }
        }
    }
}

// ====================================================================== набор текста

private const val NUM = "1234567890"
private val H1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "")
private val H2 = listOf("@", "#", "₽", "%", "&", "-", "+", "(", ")", "/", "~")
private val SYM1 = listOf("1234567890", "@#₽_&-+()/", "*\"':;!?")
private val SYM2 = listOf("~`|•√π÷×¶∆", "£€¥^°={}\\%", "©®™✓[]<>¿¡")

private class RectBox {
    var r: Rect = Rect.Zero
}

private class PreviewState {
    var label by mutableStateOf<String?>(null)
    var rect by mutableStateOf(Rect.Zero)
}

private fun feedback(view: View, kb: KbSettings) {
    if (kb.vibration) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    if (kb.sound) view.playSoundEffect(SoundEffectConstants.CLICK)
}

@Composable
private fun keyFill(special: Boolean, active: Boolean, lit: Boolean, pressed: Boolean): Color {
    val cs = MaterialTheme.colorScheme
    val kb = LocalKb.current
    val target = when {
        active -> if (pressed) cs.primary.copy(alpha = 0.7f) else cs.primary
        lit -> cs.primary.copy(alpha = 0.35f)
        special -> if (pressed) cs.surfaceVariant else cs.secondaryContainer
        else -> if (pressed) cs.secondaryContainer else cs.surfaceVariant
    }
    val c = if (kb.animations) animateColorAsState(target, tween(70), label = "key").value else target
    return c.copy(alpha = c.alpha * kb.keyAlpha / 100f)
}

@Composable
private fun keyInk(special: Boolean, active: Boolean): Color {
    val cs = MaterialTheme.colorScheme
    return if (active) cs.onPrimary else if (special) cs.onSecondaryContainer else cs.onSurface
}

@Composable
fun TypingKeyboard(
    modifier: Modifier,
    lang: Lang,
    onChar: (String) -> Unit,
    onBack: () -> Unit,
    onEnter: (() -> Unit)?,
    onLang: () -> Unit,
    autoShift: Boolean = false,
    numberRow: Boolean = false,
    cursorKeys: Boolean = false,
    onCursor: (Int) -> Unit = {}
) {
    val cs = MaterialTheme.colorScheme
    val kb = LocalKb.current
    var shift by remember { mutableIntStateOf(0) } // 0 выкл, 1 одна буква, 2 caps lock
    var lastShiftTap by remember { mutableLongStateOf(0L) }
    var sym by remember { mutableStateOf(false) }
    var symPage by remember { mutableIntStateOf(0) }
    var popup by remember { mutableStateOf<List<String>>(emptyList()) }
    val pv = remember { PreviewState() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(autoShift) { if (autoShift && shift == 0) shift = 1 }
    LaunchedEffect(popup) {
        if (popup.isNotEmpty()) {
            delay(3000)
            popup = emptyList()
        }
    }

    fun emit(t: String) {
        popup = emptyList()
        onChar(t)
    }

    val rows = if (sym) (if (symPage == 0) SYM1 else SYM2) else lang.rows
    val upper = shift != 0 && !sym

    Box(modifier.onGloballyPositioned { origin = it.positionInRoot() }) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (numberRow) {
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    NUM.forEach { d -> Key(d.toString(), preview = pv) { emit(d.toString()) } }
                }
            }
            rows.forEachIndexed { i, row ->
                Row(
                    Modifier.fillMaxWidth().weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    if (i == 2) {
                        if (sym) {
                            Key(if (symPage == 0) "2/2" else "1/2", 1.3f, true) { symPage = 1 - symPage }
                        } else {
                            Key(if (shift == 0) "⇧" else if (shift == 1) "⬆" else "⇪", 1.3f, true, lit = shift != 0) {
                                val now = System.currentTimeMillis()
                                shift = when {
                                    shift == 0 -> 1
                                    shift == 1 && now - lastShiftTap < 350 -> 2
                                    else -> 0
                                }
                                lastShiftTap = now
                            }
                        }
                    }
                    row.forEachIndexed { idx, c ->
                        val base = c.toString()
                        val out = if (upper) base.uppercase() else base
                        val h = if (sym) "" else when (i) {
                            0 -> H1.getOrElse(idx) { "" }
                            1 -> H2.getOrElse(idx) { "" }
                            else -> lang.h3.getOrElse(idx) { "" }
                        }
                        val hOut = if (upper && h.isNotEmpty() && h[0].isLetter()) h.uppercase() else h
                        val alts = if (sym) emptyList() else (lang.extra[base] ?: emptyList()).map { if (upper) it.uppercase() else it }
                        val opts = (alts + listOfNotNull(hOut.ifEmpty { null })).distinct()
                        val longAction: (() -> Unit)? = when {
                            opts.isEmpty() -> null
                            opts.size == 1 -> fun() {
                                emit(opts[0])
                                if (shift == 1) shift = 0
                            }
                            else -> fun() { popup = opts }
                        }
                        Key(out, hint = hOut.ifEmpty { null }, onLong = longAction, preview = pv) {
                            emit(out)
                            if (shift == 1) shift = 0
                        }
                    }
                    if (i == 2) RepeatKey("⌫", 1.3f, true, onBack)
                }
            }
            Row(
                Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Key(if (sym) "ABC" else "?123", 1.2f, true) {
                    sym = !sym
                    symPage = 0
                }
                Key("🌐", 1f, true) {
                    onLang()
                    sym = false
                }
                Key(",", 0.9f) { emit(",") }
                if (cursorKeys) RepeatKey("◀", 0.9f, false) { onCursor(-1) }
                SpaceKey(
                    lang.name, if (cursorKeys) 3.0f else 4.4f,
                    onSpace = { emit(" ") },
                    onSwipe = {
                        onLang()
                        sym = false
                    },
                    onCursor = onCursor
                )
                if (cursorKeys) RepeatKey("▶", 0.9f, false) { onCursor(1) }
                Key(".", 0.9f) { emit(".") }
                if (onEnter != null) Key("↵", 1.4f, true, active = true) {
                    popup = emptyList()
                    onEnter()
                }
            }
        }

        // панель выбора дополнительных символов
        if (popup.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .clip(RoundedCornerShape(12.dp))
                    .background(cs.primary)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                popup.forEach { o ->
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(cs.onPrimary.copy(alpha = 0.15f))
                            .tap {
                                emit(o)
                                if (shift == 1) shift = 0
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(o, fontSize = 24.sp, color = cs.onPrimary)
                    }
                }
            }
        }

        // увеличенный символ при нажатии
        val lbl = pv.label
        if (lbl != null) {
            val dens = LocalDensity.current
            val w = with(dens) { 56.dp.toPx() }
            val h = with(dens) { 60.dp.toPx() }
            val gap = with(dens) { 4.dp.toPx() }
            Box(
                Modifier
                    .offset {
                        val topInRoot = maxOf(0f, pv.rect.top - h - gap)
                        IntOffset(
                            (pv.rect.center.x - origin.x - w / 2).roundToInt(),
                            (topInRoot - origin.y).roundToInt()
                        )
                    }
                    .size(56.dp, 60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(cs.secondaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(lbl, fontSize = 30.sp, color = cs.onSecondaryContainer)
            }
        }
    }
}

@Composable
private fun RowScope.Key(
    label: String,
    weight: Float = 1f,
    special: Boolean = false,
    active: Boolean = false,
    lit: Boolean = false,
    hint: String? = null,
    onLong: (() -> Unit)? = null,
    preview: PreviewState? = null,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val kb = LocalKb.current
    val view = LocalView.current
    val tapCb = rememberUpdatedState(onClick)
    val longCb = rememberUpdatedState(onLong)
    val labelNow = rememberUpdatedState(label)
    val kbNow = rememberUpdatedState(kb)
    val box = remember { RectBox() }
    var pressed by remember { mutableStateOf(false) }
    Box(
        Modifier
            .weight(weight)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(keyFill(special, active, lit, pressed))
            .onGloballyPositioned { box.r = Rect(it.positionInRoot(), it.size.toSize()) }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        if (preview != null) {
                            preview.rect = box.r
                            preview.label = labelNow.value
                        }
                        tryAwaitRelease()
                        pressed = false
                        preview?.label = null
                    },
                    onLongPress = { longCb.value?.invoke() },
                    onTap = {
                        feedback(view, kbNow.value)
                        tapCb.value()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 18.sp, maxLines = 1, color = keyInk(special, active))
        if (hint != null) {
            Text(
                hint, Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 4.dp),
                fontSize = 9.sp, color = cs.onSurfaceVariant
            )
        }
    }
}

/** Клавиша с повтором при удержании (Backspace ускоряется, стрелки повторяются ровно). */
@Composable
private fun RowScope.RepeatKey(label: String, weight: Float, accelerate: Boolean = false, onRep: () -> Unit) {
    val kb = LocalKb.current
    val view = LocalView.current
    val cb = rememberUpdatedState(onRep)
    val kbNow = rememberUpdatedState(kb)
    val scope = rememberCoroutineScope()
    var pressed by remember { mutableStateOf(false) }
    Box(
        Modifier
            .weight(weight)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(keyFill(true, false, false, pressed))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed = true
                    feedback(view, kbNow.value)
                    cb.value()
                    val job = scope.launch {
                        delay(400)
                        var n = 0
                        while (true) {
                            cb.value()
                            n++
                            delay(if (accelerate) maxOf(22L, 90L - n * 4L) else 60L)
                        }
                    }
                    tryAwaitRelease()
                    job.cancel()
                    pressed = false
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 18.sp, color = keyInk(true, false))
    }
}

/**
 * Пробел: нажатие — пробел; быстрый свайп — смена языка;
 * удержание и движение пальцем — перемещение курсора.
 */
@Composable
private fun RowScope.SpaceKey(
    label: String,
    weight: Float,
    onSpace: () -> Unit,
    onSwipe: () -> Unit,
    onCursor: (Int) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val kb = LocalKb.current
    val view = LocalView.current
    val tapCb = rememberUpdatedState(onSpace)
    val swipeCb = rememberUpdatedState(onSwipe)
    val curCb = rememberUpdatedState(onCursor)
    val kbNow = rememberUpdatedState(kb)
    var pressed by remember { mutableStateOf(false) }
    Box(
        Modifier
            .weight(weight)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(keyFill(false, false, false, pressed))
            .pointerInput(Unit) {
                val slop = viewConfiguration.touchSlop
                val swipeTh = 48.dp.toPx()
                val step = 14.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown()
                    pressed = true
                    var total = 0f
                    var carry = 0f
                    var mode = 0 // 0 — не решено, 1 — свайп, 2 — курсор, 3 — свайп выполнен
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        val dx = ch.position.x - ch.previousPosition.x
                        total += dx
                        if (mode == 0 && abs(total) > slop) {
                            mode = if (ch.uptimeMillis - down.uptimeMillis >= 280) 2 else 1
                        }
                        if (mode == 1 && abs(total) > swipeTh) {
                            feedback(view, kbNow.value)
                            swipeCb.value()
                            mode = 3
                        } else if (mode == 2) {
                            carry += dx
                            while (abs(carry) >= step) {
                                val d = if (carry > 0) 1 else -1
                                curCb.value(d)
                                carry -= d * step
                            }
                        }
                        ch.consume()
                    }
                    pressed = false
                    if (mode == 0) {
                        feedback(view, kbNow.value)
                        tapCb.value()
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text("‹ $label ›", fontSize = 14.sp, maxLines = 1, color = cs.onSurface)
    }
}
