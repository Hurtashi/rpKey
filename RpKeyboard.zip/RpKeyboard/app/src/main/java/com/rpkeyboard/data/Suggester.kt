package com.rpkeyboard.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** kind: 0 слово, 1 эмодзи, 2 введённое слово, возможно с ошибкой */
class SuggItem(val text: String, val kind: Int)

data class LearnedWord(val key: String, val lang: String, val word: String, val count: Int)

/**
 * Офлайн-подсказки по языкам, предсказание следующего слова, личный словарь.
 * Всё хранится только в файлах на телефоне. Слова из словаря сами не удаляются.
 */
class Suggester(private val ctx: Context) {
    private val dicts = HashMap<String, List<String>>()
    private val sets = HashMap<String, Set<String>>()
    private val learned = HashMap<String, Int>() // "lang|слово" -> сколько раз
    private val names = HashSet<String>() // слова, которые вы пишете с заглавной
    private val pairs = HashMap<String, HashMap<String, Int>>() // "lang|предыдущее" -> следующее -> раз
    private val ignored = HashSet<String>()
    @Volatile private var lib: Set<String> = emptySet()
    @Volatile private var libPairs: Map<String, List<String>> = emptyMap()
    private val wordsFile = File(ctx.filesDir, "dictionary.txt")
    private val pairsFile = File(ctx.filesDir, "pairs.txt")
    private val legacyFile = File(ctx.filesDir, "learned.txt")
    private var dirty = 0

    init {
        try {
            if (wordsFile.exists()) {
                wordsFile.forEachLine { line ->
                    val p = line.split('\t')
                    if (p.size >= 3) {
                        val k = p[0] + "|" + p[1]
                        learned[k] = p[2].toIntOrNull() ?: 1
                        if (p.size >= 4 && p[3] == "1") names.add(k)
                    }
                }
            } else if (legacyFile.exists()) {
                legacyFile.forEachLine { line ->
                    val p = line.split('\t')
                    if (p.size == 2) {
                        val lang = if (isCyr(p[0].firstOrNull() ?: 'a')) "ru" else "en"
                        learned["$lang|${p[0]}"] = p[1].toIntOrNull() ?: 1
                    }
                }
            }
            if (pairsFile.exists()) {
                pairsFile.forEachLine { line ->
                    val p = line.split('\t')
                    if (p.size == 4) {
                        pairs.getOrPut(p[0] + "|" + p[1]) { HashMap() }[p[2]] = p[3].toIntOrNull() ?: 1
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun isCyr(c: Char) = c in 'а'..'я' || c in 'А'..'Я' || c == 'ё' || c == 'Ё' || c == 'ї' || c == 'є' || c == 'і' || c == 'ґ'

    private fun dict(lang: String): List<String> = dicts.getOrPut(lang) {
        try {
            ctx.assets.open("words_$lang.txt").bufferedReader().useLines { seq ->
                seq.map { it.trim() }.filter { it.isNotEmpty() }.toList()
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun dictSet(lang: String): Set<String> = sets.getOrPut(lang) { dict(lang).toHashSet() }

    fun isKnown(lang: String, w: String): Boolean {
        val l = w.lowercase()
        return l in dictSet(lang) || "$lang|$l" in learned || l in lib || "$lang|$l" in ignored
    }

    private fun caseFor(lang: String, prefix: String, w: String): String = when {
        "$lang|$w" in names -> w.replaceFirstChar { it.uppercase() }
        prefix.length > 1 && prefix.all { it.isUpperCase() } -> w.uppercase()
        prefix.isNotEmpty() && prefix[0].isUpperCase() -> w.replaceFirstChar { it.uppercase() }
        else -> w
    }

    /** Подсказки для начатого слова: дополнения, а для явной опечатки — исправления. */
    fun suggest(lang: String, prefix: String, limit: Int = 3): List<SuggItem> {
        if (prefix.isEmpty()) return emptyList()
        val p = prefix.lowercase()
        val cyr = langByCode(lang).cyr
        val out = LinkedHashSet<String>()
        val pre = "$lang|$p"
        learned.entries.filter { it.key.startsWith(pre) && it.key.length > pre.length }
            .sortedByDescending { it.value }.forEach { out.add(it.key.substring(lang.length + 1)) }
        lib.filter { it.startsWith(p) && it != p && isCyr(it[0]) == cyr }.sortedBy { it.length }.forEach { out.add(it) }
        for (w in dict(lang)) {
            if (out.size >= limit * 3) break
            if (w.startsWith(p) && w != p) out.add(w)
        }
        if (out.isNotEmpty() || isKnown(lang, p) || p.length < 3) {
            return out.take(limit).map { SuggItem(caseFor(lang, prefix, it), 0) }
        }
        val fixes = corrections(lang, p, 2)
        if (fixes.isEmpty()) return emptyList()
        return listOf(SuggItem(prefix, 2)) + fixes.map { SuggItem(caseFor(lang, prefix, it), 0) }
    }

    private fun corrections(lang: String, w: String, limit: Int): List<String> {
        val out = ArrayList<String>()
        fun consider(c: String) {
            if (out.size < limit && c.length >= 2 && c[0] == w[0] && kotlin.math.abs(c.length - w.length) <= 1 &&
                fixable(c, w) && c !in out
            ) out.add(c)
        }
        val pre = "$lang|"
        learned.keys.forEach { k -> if (k.startsWith(pre)) consider(k.substring(pre.length)) }
        for (c in dict(lang)) {
            if (out.size >= limit) break
            consider(c)
        }
        return out
    }

    /** Одна опечатка не в двух последних буквах (окончания не считаем ошибкой). */
    private fun fixable(dict: String, typed: String): Boolean {
        if (dict == typed) return false
        val ld = dict.length
        val lt = typed.length
        var i = 0
        val m = minOf(ld, lt)
        while (i < m && dict[i] == typed[i]) i++
        if (ld == lt) {
            if (i == ld) return false
            if (dict.substring(i + 1) == typed.substring(i + 1)) return i < ld - 2
            return i + 1 < ld && dict[i] == typed[i + 1] && dict[i + 1] == typed[i] &&
                dict.substring(i + 2) == typed.substring(i + 2)
        }
        val (s, l) = if (ld < lt) dict to typed else typed to dict
        return s.substring(i) == l.substring(i + 1) && i < l.length - 2
    }

    fun nextWords(lang: String, prev: String, limit: Int = 3): List<SuggItem> {
        val p = prev.lowercase()
        val out = LinkedHashSet<String>()
        pairs["$lang|$p"]?.entries?.sortedByDescending { it.value }?.forEach { out.add(it.key) }
        if (isCyr(p[0]) == langByCode(lang).cyr) libPairs[p]?.forEach { out.add(it) }
        return out.take(limit).map { SuggItem(caseFor(lang, "", it), 0) }
    }

    fun emojiFor(word: String): String? = EMOJI_WORDS[word.lowercase()]

    // ---------------- обучение (вызывать только если обучение разрешено)

    fun learn(lang: String, word: String, asName: Boolean = false, times: Int = 1) {
        val l = word.lowercase()
        if (l.length < 2 || !l.all { it.isLetter() }) return
        val k = "$lang|$l"
        learned[k] = (learned[k] ?: 0) + times
        if (asName) names.add(k)
        if (++dirty >= 20) save()
    }

    /** Быстро добавляет много слов сразу (для загрузки списка из файла). */
    fun learnMany(lang: String, words: List<String>): Int {
        var n = 0
        for (w in words) {
            val l = w.lowercase()
            if (l.length in 2..30 && l.all { it.isLetter() }) {
                val k = "$lang|$l"
                learned[k] = (learned[k] ?: 0) + 1
                n++
            }
        }
        save()
        return n
    }

    fun learnPair(lang: String, prev: String, next: String) {
        val a = prev.lowercase()
        val b = next.lowercase()
        if (a.length < 2 || b.length < 2 || pairs.size > 50000) return
        val m = pairs.getOrPut("$lang|$a") { HashMap() }
        m[b] = (m[b] ?: 0) + 1
        if (++dirty >= 20) save()
    }

    /** Слово оставлено как есть, но в словарь не добавляется (инкогнито). */
    fun ignore(lang: String, word: String) {
        ignored.add("$lang|${word.lowercase()}")
    }

    fun setLibrary(texts: List<String>) {
        val re = Regex("\\p{L}+")
        val words = HashSet<String>()
        val pr = HashMap<String, MutableList<String>>()
        texts.forEach { t ->
            var prev: String? = null
            re.findAll(t).forEach { m ->
                val w = m.value.lowercase()
                if (w.length >= 2) {
                    words.add(w)
                    prev?.let { a -> pr.getOrPut(a) { ArrayList() }.let { l -> if (w !in l && l.size < 6) l.add(w) } }
                }
                prev = if (w.length >= 2) w else null
            }
        }
        lib = words
        libPairs = pr
    }

    // ---------------- управление словарём

    fun listLearned(): List<LearnedWord> = learned.map { (k, c) ->
        val i = k.indexOf('|')
        LearnedWord(k, k.substring(0, i), k.substring(i + 1), c)
    }.sortedBy { it.word }

    fun removeLearned(keys: Collection<String>) {
        keys.forEach { k ->
            learned.remove(k)
            names.remove(k)
            pairs.remove(k)
            val i = k.indexOf('|')
            val lang = k.substring(0, i)
            val w = k.substring(i + 1)
            pairs.forEach { (pk, m) -> if (pk.startsWith("$lang|")) m.remove(w) }
        }
        save()
    }

    fun clearLearned() {
        learned.clear()
        names.clear()
        pairs.clear()
        ignored.clear()
        try {
            wordsFile.delete()
            pairsFile.delete()
            legacyFile.delete()
        } catch (_: Exception) {
        }
    }

    fun save() {
        try {
            wordsFile.writeText(learned.entries.joinToString("\n") { (k, c) ->
                val i = k.indexOf('|')
                "${k.substring(0, i)}\t${k.substring(i + 1)}\t$c\t${if (k in names) 1 else 0}"
            })
            pairsFile.writeText(buildString {
                pairs.forEach { (pk, m) ->
                    val i = pk.indexOf('|')
                    m.forEach { (n, c) -> append(pk.substring(0, i)).append('\t').append(pk.substring(i + 1)).append('\t').append(n).append('\t').append(c).append('\n') }
                }
            })
            dirty = 0
        } catch (_: Exception) {
        }
    }

    fun exportJson(): JSONObject {
        val words = JSONArray()
        learned.forEach { (k, c) ->
            val i = k.indexOf('|')
            words.put(JSONObject().put("l", k.substring(0, i)).put("w", k.substring(i + 1)).put("c", c).put("n", k in names))
        }
        val pr = JSONArray()
        pairs.forEach { (pk, m) ->
            val i = pk.indexOf('|')
            m.forEach { (n, c) -> pr.put(JSONObject().put("l", pk.substring(0, i)).put("p", pk.substring(i + 1)).put("n", n).put("c", c)) }
        }
        return JSONObject().put("words", words).put("pairs", pr)
    }

    /** Добавляет слова из файла к существующим. */
    fun importJson(o: JSONObject) {
        val words = o.optJSONArray("words")
        for (i in 0 until (words?.length() ?: 0)) {
            val w = words!!.optJSONObject(i) ?: continue
            val l = w.optString("l", ""); val t = w.optString("w", "")
            if (l.isEmpty() || t.isEmpty()) continue
            val k = "$l|$t"
            learned[k] = (learned[k] ?: 0) + w.optInt("c", 1)
            if (w.optBoolean("n", false)) names.add(k)
        }
        val pr = o.optJSONArray("pairs")
        for (i in 0 until (pr?.length() ?: 0)) {
            val w = pr!!.optJSONObject(i) ?: continue
            val l = w.optString("l", ""); val a = w.optString("p", ""); val b = w.optString("n", "")
            if (l.isEmpty() || a.isEmpty() || b.isEmpty()) continue
            val m = pairs.getOrPut("$l|$a") { HashMap() }
            m[b] = (m[b] ?: 0) + w.optInt("c", 1)
        }
        save()
    }
}
