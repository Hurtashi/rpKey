package com.rpkeyboard.data

class EmojiEntry(val e: String, val kw: String)
class EmojiCat(val icon: String, val name: String, val items: List<EmojiEntry>)

private fun cat(icon: String, name: String, data: String) = EmojiCat(
    icon, name,
    data.split(";").map { it.trim() }.filter { it.isNotEmpty() }.map {
        val p = it.split("|")
        EmojiEntry(p[0].trim(), (p.getOrNull(1) ?: "").lowercase())
    }
)

/** Встроенные эмодзи (Unicode до версии 10, чтобы работали на Android 8+). */
val EMOJI_CATS: List<EmojiCat> = listOf(
    cat("😀", "Смайлы",
        "😀|улыбка смайл радость smile grin happy;😃|радость улыбка smile;😄|смех радость laugh;😁|улыбка зубы grin;😆|смех laugh;😅|пот неловко sweat;😂|смех слёзы lol laugh;🤣|ржу смех rofl;😊|улыбка милый blush smile;😇|ангел angel;🙂|улыбка smile;🙃|наоборот upside;😉|подмигнул wink;😌|спокойно relieved;😍|влюблён любовь love heart eyes;😘|поцелуй kiss;😗|поцелуй kiss;😋|вкусно yum;😛|язык tongue;😜|подмигнул язык wink;🤪|псих crazy;😝|язык tongue;🤑|деньги money;🤗|обнимашки hug;🤔|думаю think hmm;🤨|сомнение brow;😐|нейтрально neutral;😑|без эмоций expressionless;😶|молчу silent;😏|ухмылка smirk;😒|недоволен unamused;🙄|закатил глаза eyeroll;😬|гримаса grimace;😮|удивление wow;😲|шок astonished;😳|смущён flushed;😢|грусть слеза sad cry;😭|плачу рыдаю cry sob;😤|злость пар angry;😠|злой angry;😡|ярость angry rage;😱|ужас страх scream fear;😨|страх fear;😰|тревога anxious;😥|грусть sad;😓|пот sweat;😴|сон спать sleep;😷|маска болею mask sick;🤒|температура болен sick;🤕|травма bandage;🤢|тошнит nausea;🤮|рвота vomit;😎|круто cool sunglasses;🤓|умник nerd;🧐|монокль monocle"),
    cat("👍", "Жесты",
        "👍|да хорошо отлично like ok thumbs;👎|нет плохо dislike thumbs;👌|ок отлично ok;✌\uFE0F|мир победа peace victory;🤞|удача fingers crossed;🤟|рок love you;🤘|рок rock;🤙|звони call me;👈|влево left;👉|вправо right;👆|вверх up;👇|вниз down;☝\uFE0F|один up;👋|привет пока hello wave bye;🤚|рука stop hand;✋|стоп stop hand;🖖|вулкан spock;👏|аплодисменты браво clap bravo;🙌|ура hooray;👐|открытые руки hands;🤲|ладони palms;🤝|рукопожатие сделка handshake deal;🙏|спасибо пожалуйста thanks please pray;✍\uFE0F|пишу write;💪|сила мышцы strong muscle;👀|смотрю глаза eyes look;👂|ухо слушаю ear;👃|нос nose;👅|язык tongue;👄|губы lips;🧠|мозг brain"),
    cat("❤\uFE0F", "Символы",
        "❤\uFE0F|любовь сердце love heart;🧡|оранжевое сердце heart;💛|жёлтое сердце heart;💚|зелёное сердце heart;💙|синее сердце heart;💜|фиолетовое сердце heart;🖤|чёрное сердце heart;💔|разбитое сердце broken heart;💕|сердца love;💞|сердца love;💓|сердце heart;💗|сердце heart;💖|сердце sparkle;💘|стрела сердце cupid;💝|подарок сердце gift;💯|сто идеально hundred perfect;💢|злость anger;💥|взрыв boom;💫|звёзды stars;💦|капли water;💨|ветер wind;🔥|огонь fire hot;⭐|звезда star;🌟|звезда star;✨|блеск sparkles;⚡|молния lightning;✅|готово галочка ok check;❌|нет крест cross no;❓|вопрос question;❗|внимание attention exclamation;‼\uFE0F|внимание attention;⚠\uFE0F|предупреждение внимание warning;🚫|запрещено forbidden;🔞|18 adult;🆗|ок ok;🆘|помощь sos;🔴|красный red;🔵|синий blue;⚫|чёрный black;⚪|белый white"),
    cat("👮", "Работа",
        "👮|полиция полицейский police;🕵\uFE0F|детектив detective;🚨|мигалка сирена siren;🚔|полиция police car;🚓|полиция police car;🚑|скорая ambulance;🚒|пожарная fire truck;🚁|вертолёт helicopter;🏥|больница hospital;🏦|банк bank;🏛\uFE0F|суд court;⚖\uFE0F|закон суд law;📄|документ документы document;📋|список планшет clipboard;📝|заметка write note;📞|телефон звонок phone;📱|телефон phone;💻|ноутбук laptop;🔑|ключ key;🔒|закрыто lock;🔓|открыто unlock;🛡\uFE0F|щит shield;💰|деньги money;💵|доллары cash;💳|карта card;🧾|чек receipt;💊|таблетка лекарство pill;💉|укол шприц syringe;🔧|ключ инструмент wrench;🔨|молоток hammer;🔦|фонарь flashlight;📻|рация радио radio;📢|объявление megaphone;📣|мегафон megaphone;🔫|пистолет gun"),
    cat("🚗", "Транспорт",
        "🚗|машина авто car;🚕|такси taxi;🚙|джип suv;🏎\uFE0F|гонка race car;🚌|автобус bus;🚎|троллейбус trolley;🚐|микроавтобус van;🚚|грузовик truck;🚛|фура truck;🚜|трактор tractor;🏍\uFE0F|мотоцикл moto;🛵|скутер scooter;🚲|велосипед bike;🛴|самокат scooter;✈\uFE0F|самолёт plane;🚤|катер boat;⛵|яхта sail;🚢|корабль ship;🏠|дом home house;🏢|офис office;🏪|магазин shop;🏬|торговый центр mall;🏨|отель hotel;⛽|заправка fuel;🚦|светофор traffic light;🚧|ремонт дорога construction;🌆|город city;🌃|ночь город night;🌉|мост bridge;🗺\uFE0F|карта map"),
    cat("🍔", "Еда",
        "🍔|бургер burger;🍟|картошка фри fries;🍕|пицца pizza;🌭|хот-дог hotdog;🥪|сэндвич sandwich;🌮|тако taco;🌯|шаурма burrito;🍗|курица chicken;🥩|мясо steak;🍖|мясо meat;🍳|яичница egg;🥞|блины pancakes;🍞|хлеб bread;🥐|круассан croissant;🧀|сыр cheese;🥗|салат salad;🍝|паста pasta;🍣|суши sushi;🍜|лапша ramen;🍩|пончик donut;🍪|печенье cookie;🎂|торт cake birthday;🍫|шоколад chocolate;🍬|конфета candy;🍦|мороженое ice cream;☕|кофе coffee;🍵|чай tea;🥤|напиток drink;🍺|пиво beer;🍻|пиво cheers;🥂|шампанское cheers;🍷|вино wine;🍸|коктейль cocktail;🥃|виски whisky;🍎|яблоко apple;🍌|банан banana;🍉|арбуз watermelon;🍇|виноград grapes;🍓|клубника strawberry;🍒|вишня cherry;🥕|морковь carrot;🌽|кукуруза corn"),
    cat("🐶", "Природа",
        "🐶|собака dog;🐱|кот кошка cat;🐭|мышь mouse;🐹|хомяк hamster;🐰|кролик rabbit;🦊|лиса fox;🐻|медведь bear;🐼|панда panda;🐯|тигр tiger;🦁|лев lion;🐮|корова cow;🐷|свинья pig;🐸|лягушка frog;🐵|обезьяна monkey;🐔|курица chicken;🐧|пингвин penguin;🐦|птица bird;🦅|орёл eagle;🦉|сова owl;🐺|волк wolf;🐴|лошадь horse;🦄|единорог unicorn;🐝|пчела bee;🦋|бабочка butterfly;🐢|черепаха turtle;🐍|змея snake;🐟|рыба fish;🐬|дельфин dolphin;🌳|дерево tree;🌲|ёлка pine;🌴|пальма palm;🌵|кактус cactus;🌸|цветок flower;🌹|роза rose;🌻|подсолнух sunflower;🌙|луна moon;☀\uFE0F|солнце sun;⛅|облачно cloud;❄\uFE0F|снег snow;⛄|снеговик snowman;🌈|радуга rainbow;🌊|волна wave")
)

/** Эмодзи-подсказки по словам. */
val EMOJI_WORDS: Map<String, String> = mapOf(
    "привет" to "👋", "здравствуйте" to "👋", "hello" to "👋", "hi" to "👋", "пока" to "👋", "bye" to "👋",
    "спасибо" to "🙏", "благодарю" to "🙏", "thanks" to "🙏", "thank" to "🙏", "пожалуйста" to "🙏", "please" to "🙏",
    "люблю" to "❤\uFE0F", "любовь" to "❤\uFE0F", "love" to "❤\uFE0F", "сердце" to "❤\uFE0F",
    "смешно" to "😂", "ахаха" to "😂", "lol" to "😂", "haha" to "😂",
    "улыбка" to "😊", "радость" to "😊", "happy" to "😊", "грустно" to "😢", "грусть" to "😢", "sad" to "😢",
    "плачу" to "😭", "злой" to "😡", "злость" to "😡", "angry" to "😡", "круто" to "😎", "cool" to "😎",
    "огонь" to "🔥", "fire" to "🔥", "да" to "👍", "хорошо" to "👍", "отлично" to "👍", "great" to "👍", "ок" to "👌", "ok" to "👌",
    "нет" to "👎", "плохо" to "👎", "bad" to "👎", "деньги" to "💰", "money" to "💰",
    "машина" to "🚗", "авто" to "🚗", "car" to "🚗", "полиция" to "🚓", "police" to "🚓",
    "врач" to "💉", "доктор" to "💉", "doctor" to "💉", "больница" to "🏥", "hospital" to "🏥",
    "дом" to "🏠", "home" to "🏠", "house" to "🏠", "еда" to "🍔", "food" to "🍔", "кофе" to "☕", "coffee" to "☕",
    "пиво" to "🍺", "beer" to "🍺", "праздник" to "🎉", "поздравляю" to "🎉", "congrats" to "🎉",
    "телефон" to "📱", "phone" to "📱", "звонок" to "📞", "сон" to "😴", "спать" to "😴", "sleep" to "😴",
    "думаю" to "🤔", "think" to "🤔", "вопрос" to "❓", "внимание" to "⚠\uFE0F", "warning" to "⚠\uFE0F",
    "оружие" to "🔫", "gun" to "🔫", "документы" to "📄", "паспорт" to "📄", "ключ" to "🔑", "key" to "🔑"
)
