package com.rpkeyboard.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rpkeyboard.RpApp
import com.rpkeyboard.data.ClipStore
import com.rpkeyboard.data.FolderEntity
import com.rpkeyboard.data.ImpFolder
import com.rpkeyboard.data.KbSettings
import com.rpkeyboard.data.LANGS
import com.rpkeyboard.data.PALETTE_NAMES
import com.rpkeyboard.data.PRESET_MODES
import com.rpkeyboard.data.Prefs
import com.rpkeyboard.data.Repo
import com.rpkeyboard.data.Suggester
import com.rpkeyboard.data.TemplateEntity
import com.rpkeyboard.data.buildInfo
import com.rpkeyboard.data.countFolders
import com.rpkeyboard.data.countTemplates
import com.rpkeyboard.data.descendants
import com.rpkeyboard.data.enabledLangs
import com.rpkeyboard.data.modeLabel
import com.rpkeyboard.data.settingsFromJson
import com.rpkeyboard.data.toJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as RpApp
        setContent { App(app.repo, app.prefs, app.suggester, app.clips, tick) }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

@Composable
fun App(repo: Repo, prefs: Prefs, suggester: Suggester, clips: ClipStore, tick: Int) {
    var settings by remember(tick) { mutableStateOf(prefs.load()) }
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Библиотека", "Словарь", "Файлы", "Настройки")
    val icons = listOf("📚", "🔤", "💾", "⚙")
    RpTheme(settings) {
        Scaffold(bottomBar = {
            NavigationBar {
                titles.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i]) }, label = { Text(t) }
                    )
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> EditorScreen(repo, settings.chatLimit)
                    1 -> DictionaryScreen(suggester)
                    2 -> FileScreen(repo, prefs, suggester, settings) { settings = it }
                    else -> SettingsScreen(prefs, suggester, clips, settings) { settings = it }
                }
            }
        }
    }
}

// ============================================================ Редактор библиотеки

sealed interface Dlg {
    data object NewFolder : Dlg
    data class RenameFolder(val f: FolderEntity) : Dlg
    data class DelFolder(val f: FolderEntity) : Dlg
    data class MoveFolder(val f: FolderEntity) : Dlg
    data object NewTpl : Dlg
    data class EditTpl(val t: TemplateEntity) : Dlg
    data class DelTpl(val t: TemplateEntity) : Dlg
    data class MoveTpl(val t: TemplateEntity) : Dlg
}

private fun pathOf(folders: List<FolderEntity>, id: Long?): String {
    val names = mutableListOf<String>()
    var c = id
    while (c != null) {
        val f = folders.firstOrNull { it.id == c } ?: break
        names.add(0, f.name)
        c = f.parentId
    }
    return "/" + names.joinToString("/")
}

@Composable
private fun Act(label: String, onClick: () -> Unit) {
    Text(label, Modifier.clickable { onClick() }.padding(horizontal = 12.dp, vertical = 8.dp))
}

@Composable
fun EditorScreen(repo: Repo, limit: Int) {
    val scope = rememberCoroutineScope()
    val folders by repo.folders.collectAsState(initial = emptyList())
    val templates by repo.templates.collectAsState(initial = emptyList())
    var cur by remember { mutableStateOf<Long?>(null) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val subs = folders.filter { it.parentId == cur }
    val tpls = templates.filter { it.folderId == cur }
    val info = remember(folders, templates) { buildInfo(folders, templates) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (cur != null) Act("←") { cur = folders.firstOrNull { it.id == cur }?.parentId }
            Text(pathOf(folders, cur), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { dlg = Dlg.NewFolder }) { Text("+ Папка") }
            OutlinedButton(onClick = { dlg = Dlg.NewTpl }) { Text("+ Шаблон") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(subs, key = { "f${it.id}" }) { f ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        Text("📁 ${f.name}", Modifier.clickable { cur = f.id }.fillMaxWidth().padding(4.dp), fontWeight = FontWeight.Bold)
                        info[f.id]?.let { fi ->
                            Text(
                                "папок: ${fi.subs} · шаблонов: ${fi.templates}" +
                                    if (fi.names.isNotEmpty()) "\n" + fi.preview() else "",
                                Modifier.padding(horizontal = 4.dp),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Act("▲") { scope.launch { repo.shiftFolder(f, -1) } }
                            Act("▼") { scope.launch { repo.shiftFolder(f, 1) } }
                            Act("✎") { dlg = Dlg.RenameFolder(f) }
                            Act("⇄") { dlg = Dlg.MoveFolder(f) }
                            Act("🗑") { dlg = Dlg.DelFolder(f) }
                        }
                    }
                }
            }
            items(tpls, key = { "t${it.id}" }) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        Text(
                            "${t.name}  ·  ${modeLabel(t.mode)}" + if (limit > 0 && t.text.length > limit) "  ⚠ ${t.text.length}" else "",
                            fontWeight = FontWeight.Bold
                        )
                        var expanded by remember(t.id) { mutableStateOf(false) }
                        Text(
                            t.text,
                            Modifier.fillMaxWidth().clickable { expanded = !expanded },
                            maxLines = if (expanded) Int.MAX_VALUE else 2,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Act(if (t.favorite) "★" else "☆") { scope.launch { repo.toggleFav(t) } }
                            Act("▲") { scope.launch { repo.shiftTemplate(t, -1) } }
                            Act("▼") { scope.launch { repo.shiftTemplate(t, 1) } }
                            Act("✎") { dlg = Dlg.EditTpl(t) }
                            Act("⇄") { dlg = Dlg.MoveTpl(t) }
                            Act("🗑") { dlg = Dlg.DelTpl(t) }
                        }
                    }
                }
            }
        }
    }

    when (val d = dlg) {
        null -> {}
        Dlg.NewFolder -> NameDialog("Новая папка", "", { n -> scope.launch { repo.addFolder(cur, n) }; dlg = null }) { dlg = null }
        is Dlg.RenameFolder -> NameDialog("Переименовать папку", d.f.name, { n -> scope.launch { repo.renameFolder(d.f, n) }; dlg = null }) { dlg = null }
        is Dlg.DelFolder -> ConfirmDialog("Удалить папку «${d.f.name}» со всем содержимым?", { scope.launch { repo.deleteFolder(d.f) }; dlg = null }) { dlg = null }
        is Dlg.MoveFolder -> PickDialog(folders, setOf(d.f.id) + descendants(folders, d.f.id), { target -> scope.launch { repo.moveFolderTo(d.f, target) }; dlg = null }) { dlg = null }
        Dlg.NewTpl -> TemplateDialog(null, limit, { n, x, m -> scope.launch { repo.saveTemplate(TemplateEntity(folderId = cur, name = n, text = x, mode = m)) }; dlg = null }) { dlg = null }
        is Dlg.EditTpl -> TemplateDialog(d.t, limit, { n, x, m -> scope.launch { repo.saveTemplate(d.t.copy(name = n, text = x, mode = m)) }; dlg = null }) { dlg = null }
        is Dlg.DelTpl -> ConfirmDialog("Удалить шаблон «${d.t.name}»?", { scope.launch { repo.deleteTemplate(d.t) }; dlg = null }) { dlg = null }
        is Dlg.MoveTpl -> PickDialog(folders, emptySet(), { target -> scope.launch { repo.moveTemplateTo(d.t, target) }; dlg = null }) { dlg = null }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onOk: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Название") }) },
        confirmButton = { TextButton(onClick = { onOk(name) }, enabled = name.isNotBlank()) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun ConfirmDialog(text: String, onOk: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text("Удалить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun TemplateDialog(initial: TemplateEntity?, limit: Int, onOk: (String, String, String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var text by remember { mutableStateOf(initial?.text ?: "") }
    val startMode = initial?.mode ?: "action"
    var preset by remember { mutableStateOf(if (startMode in PRESET_MODES) startMode else "custom") }
    var custom by remember { mutableStateOf(if (startMode in PRESET_MODES) "" else startMode) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новый шаблон" else "Шаблон") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Название кнопки") })
                OutlinedTextField(text, { text = it }, minLines = 3, label = { Text("Текст сообщения") })
                val over = limit > 0 && text.length > limit
                Text(
                    if (limit > 0) "${text.length} из $limit символов" + (if (over) " ⚠ длиннее лимита" else "") else "${text.length} символов",
                    color = if (over) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Режим чата")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PRESET_MODES.forEach { m ->
                        FilterChip(selected = preset == m, onClick = { preset = m }, label = { Text(modeLabel(m)) })
                    }
                    FilterChip(selected = preset == "custom", onClick = { preset = "custom" }, label = { Text("Свой") })
                }
                if (preset == "custom") {
                    OutlinedTextField(custom, { custom = it }, singleLine = true, label = { Text("Название режима") })
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onOk(name.trim(), text, if (preset == "custom") custom.trim().ifBlank { "chat" } else preset) },
                enabled = name.isNotBlank() && text.isNotBlank()
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

private fun flatten(all: List<FolderEntity>, parent: Long?, depth: Int, exclude: Set<Long>, out: MutableList<Pair<FolderEntity, Int>>) {
    all.filter { it.parentId == parent && it.id !in exclude }.forEach {
        out.add(it to depth)
        flatten(all, it.id, depth + 1, exclude, out)
    }
}

@Composable
private fun PickDialog(folders: List<FolderEntity>, exclude: Set<Long>, onPick: (Long?) -> Unit, onDismiss: () -> Unit) {
    val list = remember(folders, exclude) { mutableListOf<Pair<FolderEntity, Int>>().also { flatten(folders, null, 0, exclude, it) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Переместить в…") },
        text = {
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                Text("/ (корень)", Modifier.fillMaxWidth().clickable { onPick(null) }.padding(10.dp))
                list.forEach { (f, depth) ->
                    Text("📁 ${f.name}", Modifier.fillMaxWidth().clickable { onPick(f.id) }.padding(start = (10 + depth * 16).dp, top = 10.dp, bottom = 10.dp, end = 10.dp))
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

// ============================================================ Словарь

@Composable
fun DictionaryScreen(suggester: Suggester) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var version by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf("") }
    val all = remember(version) { suggester.listLearned() }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var newWord by remember { mutableStateOf("") }
    var newLang by remember { mutableStateOf("ru") }
    var confirmClear by remember { mutableStateOf(false) }
    val wordsImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
                }
                val n = suggester.learnMany(newLang, text.split(Regex("[\\s,;]+")))
                version++
                info = "Добавлено слов: $n"
            } catch (e: Exception) {
                info = "Ошибка: ${e.message}"
            }
        }
    }
    val shown = remember(all, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) all else all.filter { it.word.contains(q) }
    }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Личный словарь: ${all.size} слов", style = MaterialTheme.typography.titleMedium)
        Text(
            "Слова хранятся только на телефоне и сами не удаляются. В режиме инкогнито новые слова не добавляются.",
            style = MaterialTheme.typography.bodySmall
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LANGS.forEach { l -> FilterChip(selected = newLang == l.code, onClick = { newLang = l.code }, label = { Text(l.name) }) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(newWord, { newWord = it }, Modifier.weight(1f), singleLine = true, label = { Text("Слова через пробел") })
            Button(onClick = {
                val ws = newWord.split(Regex("[\\s,;]+")).filter { it.length >= 2 }
                if (ws.isNotEmpty()) {
                    ws.forEach { suggester.learn(newLang, it, times = 3) }
                    suggester.save()
                    info = "Добавлено слов: ${ws.size}"
                    newWord = ""
                    version++
                }
            }) { Text("Добавить") }
        }
        if (info.isNotEmpty()) Text(info, style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Поиск по словарю") })
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { wordsImport.launch(arrayOf("*/*")) }) { Text("Из файла (.txt)") }
            OutlinedButton(onClick = { selected = shown.map { it.key }.toSet() }) { Text("Выбрать все (${shown.size})") }
            OutlinedButton(onClick = {
                suggester.removeLearned(selected)
                selected = emptySet()
                version++
            }, enabled = selected.isNotEmpty()) { Text("Удалить выбранные (${selected.size})") }
            OutlinedButton(onClick = { confirmClear = true }, enabled = all.isNotEmpty()) { Text("Очистить всё") }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.key }) { w ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        selected = if (w.key in selected) selected - w.key else selected + w.key
                    },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = w.key in selected, onCheckedChange = {
                        selected = if (it) selected + w.key else selected - w.key
                    })
                    Text("${w.word}   (${w.lang}) ×${w.count}")
                }
            }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            text = { Text("Удалить весь личный словарь? Это нельзя отменить.") },
            confirmButton = {
                TextButton(onClick = {
                    suggester.clearLearned()
                    selected = emptySet()
                    confirmClear = false
                    version++
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } }
        )
    }
}

// ============================================================ Файлы: библиотека и резервные копии

private data class Pending(val tree: ImpFolder, val dups: Int)

@Composable
fun FileScreen(repo: Repo, prefs: Prefs, suggester: Suggester, settings: KbSettings, onSettings: (KbSettings) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Pending?>(null) }

    suspend fun writeText(uri: android.net.Uri, text: String) = withContext(Dispatchers.IO) {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
    }

    suspend fun readText(uri: android.net.Uri): String = withContext(Dispatchers.IO) {
        ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
    }

    val libExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                writeText(uri, repo.exportJson())
                msg = "RP-библиотека сохранена в файл"
            } catch (e: Exception) {
                msg = "Ошибка: ${e.message}"
            }
        }
    }
    val libImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val tree = repo.parseLibrary(readText(uri))
                pending = Pending(tree, repo.countDuplicates(tree))
                msg = ""
            } catch (e: Exception) {
                msg = "Ошибка: ${e.message}"
            }
        }
    }
    val backupExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val o = JSONObject().put("version", 1).put("settings", settings.toJson()).put("dictionary", suggester.exportJson())
                writeText(uri, o.toString(2))
                msg = "Настройки и словарь сохранены в файл"
            } catch (e: Exception) {
                msg = "Ошибка: ${e.message}"
            }
        }
    }
    val backupImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val o = JSONObject(readText(uri))
                var what = ""
                o.optJSONObject("settings")?.let {
                    val n = settingsFromJson(it)
                    prefs.save(n)
                    onSettings(n)
                    what += "настройки "
                }
                o.optJSONObject("dictionary")?.let {
                    suggester.importJson(it)
                    what += "словарь"
                }
                msg = if (what.isEmpty()) "В файле нет настроек и словаря" else "Загружено: ${what.trim()}"
            } catch (e: Exception) {
                msg = "Ошибка: файл не подходит (${e.message})"
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("RP-библиотека (JSON)", style = MaterialTheme.typography.titleMedium)
        Text("Экспорт — это и есть резервная копия библиотеки.")
        Button(onClick = { libExport.launch("rp-library.json") }, Modifier.fillMaxWidth()) { Text("Экспорт библиотеки") }
        OutlinedButton(onClick = { libImport.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("Импорт библиотеки") }
        HorizontalDivider()
        Text("Настройки и личный словарь", style = MaterialTheme.typography.titleMedium)
        Text("Копия настроек клавиатуры и вашего словаря. Буфер обмена в копию не входит.")
        Button(onClick = { backupExport.launch("rp-keyboard-backup.json") }, Modifier.fillMaxWidth()) { Text("Сохранить в файл") }
        OutlinedButton(onClick = { backupImport.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("Загрузить из файла") }
        if (msg.isNotEmpty()) Text(msg)
    }

    val p = pending
    if (p != null) {
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Импорт библиотеки") },
            text = { Text("Папок: ${p.tree.countFolders()}, шаблонов: ${p.tree.countTemplates()}.\nДубликатов среди них: ${p.dups}.") },
            confirmButton = {
                Column {
                    TextButton(onClick = {
                        scope.launch { repo.import(p.tree, skipDuplicates = true, replace = false); msg = "Импортировано (дубликаты пропущены)" }
                        pending = null
                    }) { Text("Объединить, пропуская дубликаты") }
                    TextButton(onClick = {
                        scope.launch { repo.import(p.tree, skipDuplicates = false, replace = false); msg = "Импортировано" }
                        pending = null
                    }) { Text("Объединить, добавить всё") }
                    TextButton(onClick = {
                        scope.launch { repo.import(p.tree, skipDuplicates = false, replace = true); msg = "Библиотека заменена" }
                        pending = null
                    }) { Text("Заменить всю библиотеку") }
                }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Отмена") } }
        )
    }
}

// ============================================================ Настройки

@Composable
fun SettingsScreen(prefs: Prefs, suggester: Suggester, clips: ClipStore, s: KbSettings, onChange: (KbSettings) -> Unit) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    fun upd(n: KbSettings) {
        prefs.save(n)
        onChange(n)
    }
    val enabled = enabledLangs(s.langs)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Установка", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }, Modifier.fillMaxWidth()) {
            Text("1. Включить RP Keyboard")
        }
        Button(onClick = {
            (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, Modifier.fillMaxWidth()) { Text("2. Выбрать RP Keyboard") }

        HorizontalDivider()
        Text("Внешний вид", style = MaterialTheme.typography.titleMedium)
        Text("Тема")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Светлая", "Тёмная", "Системная").forEachIndexed { i, n ->
                FilterChip(selected = s.themeMode == i, onClick = { upd(s.copy(themeMode = i)) }, label = { Text(n) })
            }
        }
        Text("Цветовая схема")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PALETTE_NAMES.forEachIndexed { i, n ->
                FilterChip(selected = s.palette == i, onClick = { upd(s.copy(palette = i)) }, label = { Text(n) })
            }
        }
        SliderRow("Прозрачность фона, %", s.bgAlpha, 30..100) { upd(s.copy(bgAlpha = it)) }
        SliderRow("Прозрачность клавиш, %", s.keyAlpha, 30..100) { upd(s.copy(keyAlpha = it)) }
        SwitchRow("Анимации (нажатия клавиш)", s.animations) { upd(s.copy(animations = it)) }
        SwitchRow("Звук нажатий", s.sound) { upd(s.copy(sound = it)) }
        SwitchRow("Вибрация", s.vibration) { upd(s.copy(vibration = it)) }

        HorizontalDivider()
        Text("Размеры", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Низкая" to 250, "Средняя" to 300, "Высокая" to 350).forEach { (n, h) ->
                OutlinedButton(onClick = { upd(s.copy(heightDp = h)) }) { Text(n) }
            }
        }
        SliderRow("Высота клавиатуры, dp", s.heightDp, 200..420) { upd(s.copy(heightDp = it)) }
        SliderRow("Высота в горизонтальном режиме, dp", s.heightLandDp, 120..300) { upd(s.copy(heightLandDp = it)) }
        SliderRow("Размер кнопок RP, dp", s.btnDp, 36..80) { upd(s.copy(btnDp = it)) }
        SliderRow("Размер текста RP, sp", s.textSp, 11..20) { upd(s.copy(textSp = it)) }
        SliderRow("Количество столбцов RP", s.columns, 1..4) { upd(s.copy(columns = it)) }
        SliderRow("Строк текста на кнопке (0 — скрыть)", s.previewLines, 0..4) { upd(s.copy(previewLines = it)) }

        HorizontalDivider()
        Text("Ввод", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Цифровой ряд 1–0", s.numberRow) { upd(s.copy(numberRow = it)) }
        SwitchRow("Стрелки курсора рядом с пробелом", s.cursorKeys) { upd(s.copy(cursorKeys = it)) }
        SwitchRow("Автоматическая заглавная буква", s.autoCaps) { upd(s.copy(autoCaps = it)) }
        Text("Языки (переключение: свайп по пробелу или 🌐)")
        LANGS.forEach { l ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = l.code in enabled, onCheckedChange = { on ->
                    val n = if (on) (enabled + l.code).distinct() else enabled - l.code
                    if (n.isNotEmpty()) upd(s.copy(langs = n.joinToString(",")))
                })
                Text(l.name)
            }
        }

        HorizontalDivider()
        Text("Подсказки и словарь", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Подсказки слов", s.suggest) { upd(s.copy(suggest = it)) }
        SwitchRow("Предсказывать следующее слово", s.nextWord) { upd(s.copy(nextWord = it)) }
        SwitchRow("Подсказывать эмодзи", s.emojiSuggest) { upd(s.copy(emojiSuggest = it)) }
        SwitchRow("Запоминать мои слова (только на телефоне)", s.learn) { upd(s.copy(learn = it)) }
        SwitchRow("Режим инкогнито (не запоминать слова и буфер)", s.incognito) { upd(s.copy(incognito = it)) }

        HorizontalDivider()
        Text("Буфер обмена и чат", style = MaterialTheme.typography.titleMedium)
        SwitchRow("История буфера обмена (100 записей)", s.clipboard) { upd(s.copy(clipboard = it)) }
        SliderRow("Лимит символов в чате (0 — выкл.)", s.chatLimit, 0..300) { upd(s.copy(chatLimit = it)) }

        HorizontalDivider()
        Text("RP-библиотека", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Подсказка режима чата", s.hintMode) { upd(s.copy(hintMode = it)) }
        SwitchRow("Показывать «Недавние»", s.showRecents) { upd(s.copy(showRecents = it)) }
        SwitchRow("Показывать «Избранное»", s.showFavorites) { upd(s.copy(showFavorites = it)) }

        HorizontalDivider()
        Text("Сброс", style = MaterialTheme.typography.titleMedium)
        Text("RP-библиотека при сбросах не удаляется.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = {
            confirm = "Сбросить все настройки к начальным?" to {
                prefs.resetSettings()
                onChange(prefs.load())
            }
        }, Modifier.fillMaxWidth()) { Text("Сбросить настройки") }
        OutlinedButton(onClick = {
            confirm = "Удалить весь личный словарь?" to { suggester.clearLearned() }
        }, Modifier.fillMaxWidth()) { Text("Очистить словарь") }
        OutlinedButton(onClick = {
            confirm = "Очистить весь буфер обмена, включая закреплённое?" to { clips.clearAll() }
        }, Modifier.fillMaxWidth()) { Text("Очистить буфер обмена") }
        Button(onClick = {
            confirm = "Общий сброс: настройки, словарь и буфер обмена. RP-библиотека останется. Продолжить?" to {
                prefs.resetSettings()
                suggester.clearLearned()
                clips.clearAll()
                onChange(prefs.load())
            }
        }, Modifier.fillMaxWidth()) { Text("Общий сброс") }
    }

    val c = confirm
    if (c != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            text = { Text(c.first) },
            confirmButton = {
                TextButton(onClick = {
                    c.second()
                    confirm = null
                }) { Text("Да") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun SwitchRow(label: String, v: Boolean, onV: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = onV)
    }
}

@Composable
private fun SliderRow(label: String, v: Int, r: IntRange, onV: (Int) -> Unit) {
    Column {
        Text("$label: $v")
        Slider(value = v.toFloat(), onValueChange = { onV(it.toInt()) }, valueRange = r.first.toFloat()..r.last.toFloat())
    }
}
